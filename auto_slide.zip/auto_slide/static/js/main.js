function main (delay) {
    console.log(123);
}
document.addEventListener('DOMContentLoaded', main(10), false);
